jQuery(function($){
	"use strict";
	$(".redux-message,.notice.envato-market-notice").hide();
});