<?php
return $change_log = '

17 November 2021 - Version 2.3
    UPDATED! Blokco Core Plugin
    UPDATED! Revolution Slider Plugin

01 August 2021 - Version 2.2
    UPDATED! Blokco Core Plugin
    UPDATED! Eventer Plugin
    UPDATED! Revolution Slider Plugin
    UPDATED! WP Bakery Page Builder Plugin

03 April 2021 - Version 2.1
	UPDATED! Compatibility for WP version 5.7
	UPDATED! Eventer Plugin
    UPDATED! Revolution Slider Plugin
    UPDATED! WP Bakery Page Builder Plugin
    FIXED! Some styling bugs

09 November 2020 - Version 2.0
    UPDATED! Revolution Slider Plugin
    UPDATED! WP Bakery Page Builder Plugin
    UPDATED! Eventer Plugin

14 August 2020 - Version 1.9
	UPDATED! Compatibility for WP version 5.5
	UPDATED! Eventer Plugin
    UPDATED! Revolution Slider Plugin
    FIXED! Some styling bugs

01 March 2020 - Version 1.8
    UPDATED! Blokco Core Plugin
    UPDATED! WPBakery Page Builder Plugin
    UPDATED! Revolution Slider Plugin
    FIXED! Some styling bugs

22 September 2019 - Version 1.7
    UPDATED! Blokco Core Plugin
    UPDATED! Revolution Slider Plugin
    UPDATED! WP Bakery Page Builder Plugin
    UPDATED! Virtual Coins Widget Plugin
    UPDATED! Eventer Plugin
    FIXED! An issue with new revolution slider used in page options
    FIXED! Some styling Bugs

26 May 2019 - Version 1.6
	UPDATED! Blokco Core Plugin
	UPDATED! WPBakery Plugin
	UPDATED! Revolution Slider Plugin
	UPDATED! Eventer Plugin
	FIXED! Some styling bugs

06 July 2018 - Version 1.5
	UPDATED! Eventer Plugin
	UPDATED! Blokco Core Plugin
	UPDATED! Blokco Dashboard to include more advanced Demo Importer and Plugin Activator
	
06 July 2018 - Version 1.4.2
	UPDATED! Visual Composer Plugin
	UPDATED! Slider Revolution Plugin
	FIXED! An error with one page nav when linked from inner pages

16 June 2018 - Version 1.4.1
	FIXED! Full width row of page builder breaking in LTR layouts
	FIXED! Overflow visibility issue in one page layouts

13 June 2018 - Version 1.4
	NEW! ICO Advisor demo added
	UPDATED! Block Core plugin to include new demo
	UPDATED! Virtual coin widgets plugin
	UPDATED! Eventer plugin
	UPDATED! Shortcodes to have new features
	FIXED! Some styling bugs
	FIXED! Theme registration function

25 May 2018 - Version 1.3
	NEW! ICO Landing Dark new demo added
	NEW! Eventer plugin docs added
	UPDATED! Countdown plugin shortcode for page builder to add more styles
	UPDATED! Block Core plugin
	UPDATED! Language .pot file to add new static text strings
	UPDATED! Eventer plugin
	FIXED! Some styling bugs

20 May 2018 - Version 1.1
	NEW! Countdown Timer shortcode for page builder added
	NEW! Option to add your own text in video play shortcode
	UPDATED! Block Core plugin to reset the demo data
	FIXED! Some styling bugs

18 May 2018 - Version 1.0
	INITIAL RELEASE
';
